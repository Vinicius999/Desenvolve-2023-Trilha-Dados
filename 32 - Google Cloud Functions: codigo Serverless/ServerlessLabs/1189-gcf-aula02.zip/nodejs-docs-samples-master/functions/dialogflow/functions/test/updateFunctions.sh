#!/bin/bash
# Shell script to emulate the GCP functions

functions-emulator deploy getOAuthToken --trigger-http
