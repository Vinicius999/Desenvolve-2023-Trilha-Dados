# Test public certificate files

The certificates in this folder are only provided for testing and should not be
used for registering or connecting your devices.
