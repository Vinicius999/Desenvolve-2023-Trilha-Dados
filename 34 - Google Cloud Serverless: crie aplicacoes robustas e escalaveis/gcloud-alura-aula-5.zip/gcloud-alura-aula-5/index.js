exports.recebeAtividade = require('./funcoes/recebeAtividade')
exports.insereAtividade = require('./funcoes/insereAtividade')