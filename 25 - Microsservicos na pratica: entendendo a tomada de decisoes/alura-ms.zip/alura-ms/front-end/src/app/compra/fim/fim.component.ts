import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fim',
  templateUrl: './fim.component.html',
  styleUrls: ['./fim.component.css']
})
export class FimComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
