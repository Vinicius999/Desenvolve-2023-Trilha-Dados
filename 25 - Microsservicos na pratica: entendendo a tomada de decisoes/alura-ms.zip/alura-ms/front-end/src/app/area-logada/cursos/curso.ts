export type Curso = {
  id: number,
  titulo: string,
  url: string,
  icone: string,
  assistido: boolean,
}
