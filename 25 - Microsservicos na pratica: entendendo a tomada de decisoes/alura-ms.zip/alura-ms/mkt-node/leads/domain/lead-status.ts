enum LeadStatus {
    INTERESTED,
    CUSTOMER,
    CANCELED
};

export default LeadStatus;